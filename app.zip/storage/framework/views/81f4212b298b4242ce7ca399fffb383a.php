
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">Import Job Details</h3>
        <a href="<?php echo e(route('admin.import-jobs.list')); ?>" class="btn btn-primary">
            <i class="bi bi-arrow-left me-1"></i>Back to List
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <th>Admin Name</th>
                        <td><?php echo e($job->admin->name ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Original Filename</th>
                        <td><?php echo e($job->original_filename); ?></td>
                    </tr>
                    <tr>
                        <th>Stored Filename</th>
                        <td><?php echo e($job->stored_filename); ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <?php if($job->status == 'uploaded'): ?> <span class="badge bg-primary">Uploaded</span> <?php endif; ?>
                            <?php if($job->status == 'validating'): ?> <span class="badge bg-info">Validating</span> <?php endif; ?>
                            <?php if($job->status == 'failed'): ?> <span class="badge bg-danger">Failed</span> <?php endif; ?>
                            <?php if($job->status == 'validated'): ?> <span class="badge bg-success">Validated</span> <?php endif; ?>
                            <?php if($job->status == 'processing'): ?> <span class="badge bg-warning text-dark">Processing</span> <?php endif; ?>
                            <?php if($job->status == 'completed'): ?> <span class="badge bg-success">Completed</span> <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>As of Month</th>
                        <td><?php echo e($job->as_of_month); ?></td>
                    </tr>
                    <tr>
                        <th>Total Rows</th>
                        <td><?php echo e($job->total_rows); ?></td>
                    </tr>
                    <tr>
                        <th>Valid Rows</th>
                        <td><?php echo e($job->valid_rows); ?></td>
                    </tr>
                    <tr>
                        <th>Invalid Rows</th>
                        <td><?php echo e($job->invalid_rows); ?></td>
                    </tr>
                    <tr>
                        <th>Summary</th>
                        <td>
                            <?php if($job->summary): ?>
                                <pre><?php echo e(json_encode(json_decode($job->summary), JSON_PRETTY_PRINT)); ?></pre>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Created At</th>
                        <td><?php echo e($job->created_at->format('d M Y H:i')); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e($job->updated_at->format('d M Y H:i')); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/import-jobs/show.blade.php ENDPATH**/ ?>