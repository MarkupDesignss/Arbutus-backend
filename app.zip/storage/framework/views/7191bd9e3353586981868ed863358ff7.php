<aside class="sidebar" id="sidebar">
    <div class="sidebar-nav">

        <div class="nav-section">Main</div>

        <!-- Dashboard -->
        <a href="<?php echo e(route('admin.dashboard')); ?>"
            class="nav-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-speedometer2"></i>
            <span class="nav-label">Dashboard</span>
        </a>

        <ul>
            <li
                class="sidebar-item has-submenu <?php echo e(request()->routeIs('admin.asset.class.*') || request()->routeIs('admin.type.*') || request()->routeIs('admin.strategie.*') || request()->routeIs('admin.category.*') || request()->routeIs('admin.risk.rating.*') || request()->routeIs('admin.firms.*') ? 'open active' : ''); ?>">
                <a href="javascript:void(0);" class="nav-item sidebar-link">
                    <i class="nav-icon bi bi-tree-fill"></i>
                    <span class="nav-label">Master Green</span>
                    <i class="bi bi-chevron-down ms-auto arrow"></i>
                </a>

                <ul class="submenu">
                    <li>
                        <a href="<?php echo e(route('admin.asset.class.list')); ?>"
                            class="<?php echo e(request()->routeIs('admin.asset.class.*') ? 'active' : ''); ?>">
                            <i class="bi bi-boxes"></i>
                            <span>Asset Class</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.type.list')); ?>"
                            class="<?php echo e(request()->routeIs('admin.type.*') ? 'active' : ''); ?>">
                            <i class="bi bi-tags"></i>
                            <span>Types</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.strategie.list')); ?>"
                            class="<?php echo e(request()->routeIs('admin.strategie.*') ? 'active' : ''); ?>">
                            <i class="bi bi-lightning-fill"></i>
                            <span>Strategies</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.category.list')); ?>"
                            class="<?php echo e(request()->routeIs('admin.category.*') ? 'active' : ''); ?>">
                            <i class="bi bi-collection"></i>
                            <span>Categories</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.risk.rating.list')); ?>"
                            class="<?php echo e(request()->routeIs('admin.risk.rating.*') ? 'active' : ''); ?>">
                            <i class="bi bi-exclamation-triangle"></i>
                            <span>Risk Rating</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.firms.list')); ?>"
                            class="<?php echo e(request()->routeIs('admin.firms.*') ? 'active' : ''); ?>">
                            <i class="bi bi-building"></i>
                            <span>Firm</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>

        <a href="<?php echo e(route('admin.funds.list')); ?>"
            class="nav-item <?php echo e(request()->routeIs('admin.funds.*') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-wallet2"></i>
            <span class="nav-label">Fund</span>
        </a>

        <a href="<?php echo e(route('admin.pages.list')); ?>"
            class="nav-item <?php echo e(request()->routeIs('admin.pages.*') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-file-text"></i>
            <span class="nav-label">Page</span>
        </a>

        <div class="nav-divider"></div>

        <div class="nav-section">Account</div>

        <!-- Profile -->
        <a href="<?php echo e(route('admin.profile')); ?>"
            class="nav-item <?php echo e(request()->routeIs('admin.profile') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-person"></i>
            <span class="nav-label">Profile</span>
        </a>

        <!-- Change Password -->
        <a href="<?php echo e(route('admin.password.change')); ?>" class="nav-item">
            <i class="nav-icon bi bi-key"></i>
            <span class="nav-label">Change Password</span>
        </a>

        <!-- Logout -->
        <form method="POST" action="<?php echo e(route('admin.logout')); ?>" class="nav-item">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-link nav-link p-0 m-0 text-start">
                <i class="nav-icon bi bi-box-arrow-right"></i>
                <span class="nav-label">Logout</span>
            </button>
        </form>

    </div>
</aside><?php /**PATH /home/markcawm/public_html/arbutus-partner/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>