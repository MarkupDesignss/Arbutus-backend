
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">Website Settings</h3>
    </div>
    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="table-responsive">
            <table class="table table-bordered" id="settings-table">
                <thead class="table-light">
                    <tr>
                        <th style="width: 250px;">Key</th>
                        <th style="width: 250px;">Value</th>
                        <th style="width: 80px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><input type="text" name="settings[keys][]" value="<?php echo e($key); ?>" class="form-control" required
                                readonly></td>
                        <td><input type="text" name="settings[values][]" value="<?php echo e($value); ?>" class="form-control"
                                required></td>
                        <td class="text-center">
                            <button type="button" class="btn btn-danger btn-sm remove-row">&times;</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td><input type="text" name="settings[keys][]" class="form-control" placeholder="Enter key"
                                required></td>
                        <td><input type="text" name="settings[values][]" class="form-control" placeholder="Enter value"
                                required></td>
                        <td class="text-center">
                            <button type="button" class="btn btn-danger btn-sm remove-row" disabled>&times;</button>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
            <button type="button" id="add-row-btn" class="btn btn-primary btn-custom-add">
                <i class="bi bi-plus-circle me-1"></i> Add More
            </button>

            <button type="submit" class="btn btn-success">Save Settings</button>
        </div>
    </form>
</div>
<script>
document.getElementById('add-row-btn').addEventListener('click', function() {
    const tableBody = document.querySelector('#settings-table tbody');
    const newRow = document.createElement('tr');

    newRow.innerHTML = `
            <td><input type="text" name="settings[keys][]" class="form-control" placeholder="Enter key" required></td>
            <td><input type="text" name="settings[values][]" class="form-control" placeholder="Enter value" required></td>
            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm remove-row">&times;</button>
            </td>
        `;
    tableBody.appendChild(newRow);
});

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('remove-row')) {
        e.target.closest('tr').remove();
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>