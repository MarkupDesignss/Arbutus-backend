
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size:1.5rem;color:#0d6efd;" class="mb-0 fw-bold">Access Rule Details</h3>
        <a href="<?php echo e(route('admin.access.rule.list')); ?>" class="btn btn-primary btn-custom-add">
            <i class="bi bi-arrow-left me-1"></i>Back to List
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th width="200">Module</th>
                    <td><?php echo e($access_rule->module); ?></td>
                </tr>
                <tr>
                    <th>Rule Type</th>
                    <td><span class="badge bg-info"><?php echo e(ucfirst($access_rule->rule_type)); ?></span></td>
                </tr>
                <tr>
                    <th>Rule Key</th>
                    <td><?php echo e($access_rule->rule_key); ?></td>
                </tr>
                <tr>
                    <th>Label</th>
                    <td><?php echo e($access_rule->label); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php echo $access_rule->status ? '<span class="badge bg-success">Active</span>' :
                        '<span class="badge bg-danger">Inactive</span>'; ?>

                    </td>
                </tr>
                <tr>
                    <th>Created At</th>
                    <td><?php echo e($access_rule->created_at->format('d M Y h:i A')); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/access_rules/view.blade.php ENDPATH**/ ?>