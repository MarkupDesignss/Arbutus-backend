
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">Fund Details</h3>
        <a href="<?php echo e(route('admin.funds.list')); ?>" class="btn btn-primary">
            <i class="bi bi-arrow-left me-1"></i>Back to List
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Fund Overview</h5>
        </div>
        <div class="card-body">
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <strong>Fund DATA Key:</strong>
                    <p class="text-muted"><?php echo e($fund->fundatakey); ?></p>
                </div>
                <div class="col-md-4">
                    <strong>Symbol Code:</strong>
                    <p class="text-muted"><?php echo e($fund->symbol_code ?? '-'); ?></p>
                </div>
                <div class="col-md-4">
                    <strong>Fund Name:</strong>
                    <p class="text-muted"><?php echo e($fund->fund_name); ?></p>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <strong>Firm:</strong>
                    <p class="text-muted"><?php echo e($fund->firm->name ?? '-'); ?></p>
                </div>
                <div class="col-md-4">
                    <strong>Asset Class:</strong>
                    <p class="text-muted"><?php echo e($fund->assetClass->name ?? '-'); ?></p>
                </div>
                <div class="col-md-4">
                    <strong>Type:</strong>
                    <p class="text-muted"><?php echo e($fund->type->name ?? '-'); ?></p>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <strong>Strategy:</strong>
                    <p class="text-muted"><?php echo e($fund->strategy->name ?? '-'); ?></p>
                </div>
                <div class="col-md-4">
                    <strong>Category:</strong>
                    <p class="text-muted"><?php echo e($fund->category->name ?? '-'); ?></p>
                </div>
                <div class="col-md-4">
                    <strong>Risk Rating:</strong>
                    <p class="text-muted"><?php echo e($fund->riskRating->name ?? '-'); ?></p>
                </div>
            </div>

            <!-- Performance Metrics -->
            <div class="card mb-4">
                <div class="card-header bg-secondary text-white">
                    <h6 class="mb-0">Performance Metrics (%)</h6>
                </div>                
            </div>

            <!-- Links & Status -->
            <div class="row g-3 mb-3">
                <div class="col-md-4">
                    <strong>Fund Library:</strong>
                    <?php if($fund->fund_library_link): ?>
                        <p><a href="<?php echo e($fund->fund_library_link); ?>" target="_blank" class="link-primary"><?php echo e($fund->fund_library_link); ?></a></p>
                    <?php else: ?>
                        <p>-</p>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <strong>External Link:</strong>
                    <?php if($fund->external_link): ?>
                        <p><a href="<?php echo e($fund->external_link); ?>" target="_blank" class="link-primary"><?php echo e($fund->external_link); ?></a></p>
                    <?php else: ?>
                        <p>-</p>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <strong>Status:</strong>
                    <?php if($fund->status == 1): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Inactive</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/funds/view.blade.php ENDPATH**/ ?>