
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">Contact List</h3>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="text-uppercase">
                        <tr>
                            <th scope="col" style="width: 50px;  background-color: #f1f5f9;">#</th>
                            <th scope="col" style="width: 150px;  background-color: #f1f5f9;">First name</th>
                            <th scope="col" style="width: 150px;  background-color: #f1f5f9;">Last name</th>
                            <th scope="col" style="width: 150px;  background-color: #f1f5f9;">Mobile</th>
                            <th scope="col" style="width: 150px;  background-color: #f1f5f9;">Email</th>
                            <th scope="col" style="width: 100px;  background-color: #f1f5f9;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($list->fname); ?></td>
                                <td><?php echo e($list->lname); ?></td>
                                <td><?php echo e($list->mobile); ?></td>
                                <td><?php echo e($list->email); ?></td>
                                
                                <td>
                                    <div class="d-flex gap-2">                                       
                                        <a href="<?php echo e(route('admin.contact.show', $list->id)); ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-eye"></i></a>
                                         <form action="<?php echo e(route('admin.contact.destroy', $list->id)); ?>" method="POST"
                                        class="delete-form">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-sm btn-outline-danger delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center">No contact found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="mt-3"><?php echo e($contacts->links('pagination::bootstrap-5')); ?></div>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        let form = this.closest('form');

        Swal.fire({
            title: 'Are you sure?',
            text: "You will not be able to recover this Data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e53935',
            cancelButtonColor: '#9e9e9e',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>