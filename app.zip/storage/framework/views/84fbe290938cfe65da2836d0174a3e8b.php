
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3 listing_name">
        <h3 style="font-size:1.5rem;color:#0d6efd;" class="mb-0 fw-bold">Subscription List</h3>
        <a href="<?php echo e(route('admin.subscriptions.create')); ?>" class="btn btn-primary btn-custom-add">
            <i class="bi bi-plus-circle me-1"></i>Add New
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col" style="width: 50px;  background-color: #f1f5f9;">SN</th>
                        <th scope="col" style="width: 100px;  background-color: #f1f5f9;">Name</th>
                        <th scope="col" style="width: 50px;  background-color: #f1f5f9;">Monthly</th>
                        <th scope="col" style="width: 50px;  background-color: #f1f5f9;">Yearly</th>
                        <th scope="col" style="width: 50px;  background-color: #f1f5f9;">Popular</th>
                        <th scope="col" style="width: 50px;  background-color: #f1f5f9;">Status</th>
                        <th scope="col" style="width: 150px;  background-color: #f1f5f9;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($sub->name); ?></td>
                        <td><?php echo e($sub->monthly_price); ?></td>
                        <td><?php echo e($sub->yearly_price); ?></td>
                        <td><?php echo $sub->is_popular ? '<span class="badge bg-warning">Yes</span>' : '<span
                                class="badge bg-danger">No</span>'; ?></td>
                        <td><?php echo $sub->is_active ? '<span class="badge bg-success">Active</span>' : '<span
                                class="badge bg-danger">Inactive</span>'; ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.subscriptions.edit',$sub->id)); ?>"
                                class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                            <a href="<?php echo e(route('admin.subscriptions.show',$sub->id)); ?>"
                                class="btn btn-sm btn-outline-info" data-bs-toggle="tooltip" title="View">
                                <i class="fas fa-eye"></i>
                            </a>
                            <form action="<?php echo e(route('admin.subscriptions.destroy',$sub->id)); ?>" method="POST"
                                class="d-inline delete-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger" data-bs-toggle="tooltip"
                                    title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($subscriptions->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>
<script>
document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        let form = this.closest('form');

        Swal.fire({
            title: 'Are you sure?',
            text: "You will not be able to recover this Data!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e53935',
            cancelButtonColor: '#9e9e9e',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/subscriptions/index.blade.php ENDPATH**/ ?>