<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Form</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin-login/style.css')); ?>">
    <style>
        .footer {
        position: absolute;
        bottom: 10px;
        right: 20px;
        font-size: 14px;
        color: #0c0606ff;
    }

    .footer a {
        color: #007bff;
        text-decoration: none;
    }
    .footer a:hover {
        text-decoration: underline;
    }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="neu-icon">
                    <div class="icon-inner">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                            <circle cx="12" cy="7" r="4" />
                        </svg>
                    </div>
                </div>
                <h2>Welcome back</h2>
                <p>Please sign in to continue</p>
            </div>

            <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>" class="login-form" id="loginForm" novalidate>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="input-group neu-input <?php echo e(old('email') ? 'has-value' : ''); ?>">
                        <input type="email" id="email" name="email" required autocomplete="email" placeholder=" " value="<?php echo e(old('email')); ?>">
                        <label for="email">Email address</label>
                        <div class="input-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                                <polyline points="22,6 12,13 2,6" />
                            </svg>
                        </div>
                    </div>
                    <span class="error-message <?php echo e(session('error') || $errors->has('email') ? 'show' : ''); ?>" id="emailError"><?php echo e(session('error') ?? $errors->first('email')); ?></span>
                </div>

                <div class="form-group">
                    <div class="input-group neu-input password-group <?php echo e(old('password') ? 'has-value' : ''); ?>">
                        <input type="password" id="password" name="password" required autocomplete="current-password"
                            placeholder=" ">
                        <label for="password">Password</label>
                        <div class="input-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                                <path d="M7 11V7a5 5 0 0110 0v4" />
                            </svg>
                        </div>
                        <button type="button" class="password-toggle neu-toggle" id="passwordToggle"
                            aria-label="Toggle password visibility">
                            <svg class="eye-open" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                <circle cx="12" cy="12" r="3" />
                            </svg>
                            <svg class="eye-closed" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2">
                                <path
                                    d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                                <line x1="1" y1="1" x2="23" y2="23" />
                            </svg>
                        </button>
                    </div>
                    <span class="error-message" id="passwordError"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                </div>

                <div class="form-options">
                    <div class="remember-wrapper">
                        <input type="checkbox" id="remember" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label for="remember" class="checkbox-label">
                            <div class="neu-checkbox">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                                    <polyline points="20 6 9 17 4 12" />
                                </svg>
                            </div>
                            Remember me
                        </label>
                    </div>                    
                </div>

                <button type="submit" class="neu-button login-btn">
                    <span class="btn-text">Sign In</span>
                    <div class="btn-loader">
                        <div class="neu-spinner"></div>
                    </div>
                </button>
            </form> 
                    
        </div>
    </div>
<div class="footer">
        <strong>
            © 2026, made with ❤️ by
            <a href="https://www.markupdesigns.com/" target="_blank">Markup Design</a>.
        </strong>
        All rights reserved.
        <a href="<?php echo e(url('/')); ?>">Back</a>
    </div>
    <script src="../../shared/js/form-utils.js"></script>
    <!-- <script src="script.js"></script> -->
    <script src="<?php echo e(asset('assets/admin-login/script.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>