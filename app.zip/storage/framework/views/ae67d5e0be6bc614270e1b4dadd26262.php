
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between mb-3">
        <h3 style="font-size:1.5rem;color:#0d6efd;" class="fw-bold">Add Plan Access</h3>
        <a href="<?php echo e(route('admin.plan.access.list')); ?>" class="btn btn-primary btn-custom-add">
            <i class="bi bi-arrow-left"></i> Back
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.plan.access.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">

                    <div class="col-md-4 mb-3">
                        <label>Subscription</label>
                        <select name="subscription_id" class="form-select">
                            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>Access Rule</label>
                        <select name="access_rule_id" class="form-select">
                            <?php $__currentLoopData = $access_rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($r->id); ?>"><?php echo e($r->label); ?> (<?php echo e($r->module); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>Status</label>
                        <select name="status" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>

                </div>

                <div class="mt-3 text-end">
                    <button class="btn btn-success">Save Mapping</button>
                    <a href="<?php echo e(route('admin.plan.access.list')); ?>" class="btn btn-danger">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/plan_accesses/add.blade.php ENDPATH**/ ?>