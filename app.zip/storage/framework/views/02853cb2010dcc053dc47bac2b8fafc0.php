
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3 listing_name">
        <h3 style="font-size:1.5rem;color:#0d6efd;" class="mb-0 fw-bold">Plan Access Mapping</h3>
        <a href="<?php echo e(route('admin.plan.access.create')); ?>" class="btn btn-primary btn-custom-add">
            <i class="bi bi-plus-circle me-1"></i>Add Mapping
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col" style="width: 50px;  background-color: #f1f5f9;">#</th>
                    <th scope="col" style="width: 100px;  background-color: #f1f5f9;">Subscription</th>
                    <th scope="col" style="width: 150px;  background-color: #f1f5f9;">Access Rule</th>
                    <th scope="col" style="width: 150px;  background-color: #f1f5f9;">Type</th>
                    <th scope="col" style="width: 50px;  background-color: #f1f5f9;">Status</th>
                    <th scope="col" style="width: 200px;  background-color: #f1f5f9;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $plan_accesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pa->subscription->name); ?></td>
                    <td><?php echo e($pa->accessRule->label); ?></td>
                    <td><span class="badge bg-info"><?php echo e(ucfirst($pa->accessRule->rule_type)); ?></span></td>
                    <td><?php echo $pa->status ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>'; ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.plan.access.edit',$pa->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                        <a href="<?php echo e(route('admin.plan.access.show',$pa->id)); ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-eye"></i></a>
                        <form action="<?php echo e(route('admin.plan.access.destroy',$pa->id)); ?>" method="POST" class="d-inline delete-form">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger delete-btn"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($plan_accesses->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>

<script>
document.querySelectorAll('.delete-btn').forEach(btn=>{
    btn.addEventListener('click',function(e){
        e.preventDefault();
        let form=this.closest('form');
        Swal.fire({
            title:'Delete Mapping?',
            text:'This feature will be removed from plan!',
            icon:'warning',
            showCancelButton:true,
            confirmButtonColor:'#e53935',
            confirmButtonText:'Yes delete'
        }).then(r=>{ if(r.isConfirmed) form.submit(); });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/plan_accesses/index.blade.php ENDPATH**/ ?>