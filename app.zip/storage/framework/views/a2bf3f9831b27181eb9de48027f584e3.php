
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
     <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">Blog Details</h3>
        <a href="<?php echo e(route('admin.blog.list')); ?>" class="btn btn-primary btn-custom-add">
            <i class="bi bi-arrow-left me-1"></i>Back to List
        </a>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Title:</div>
                <div class="col-md-9"><?php echo e($blog->title); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Slug:</div>
                <div class="col-md-9"><?php echo e($blog->slug); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Author:</div>
                <div class="col-md-9"><?php echo e($blog->author_name); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Post Date:</div>
                <div class="col-md-9"><?php echo e(date('d M Y',strtotime($blog->post_date))); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Type:</div>
                <div class="col-md-9"><?php echo e($blog->type); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Video Url:</div>
                <div class="col-md-9"><?php echo e($blog->video_url); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Status:</div>
                <div class="col-md-9">
                    <?php if($blog->status): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Inactive</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Short Description:</div>
                <div class="col-md-9"><?php echo e($blog->short_description); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3 fw-bold">Long Description:</div>
                <div class="col-md-9"><?php echo nl2br($blog->long_description); ?></div>
            </div>

            <div class="row">
                <div class="col-md-3 fw-bold">Image:</div>
                <div class="col-md-9">
                    <img src="<?php echo e(asset('storage/blogs/'.$blog->image)); ?>" width="60" class="rounded shadow">
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/blogs/view.blade.php ENDPATH**/ ?>