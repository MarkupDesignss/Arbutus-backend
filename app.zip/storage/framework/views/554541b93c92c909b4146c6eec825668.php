
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 style="font-size:1.5rem;color:#0d6efd;" class="mb-0 fw-bold">View Subscription</h3>
        <a href="<?php echo e(route('admin.subscriptions.list')); ?>" class="btn btn-primary">
            <i class="bi bi-arrow-left me-1"></i>Back to List
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">

            <div class="row">

                <!-- Name -->
                <div class="col-md-6 mb-3">
                    <strong>Name:</strong>
                    <p><?php echo e($subscription->name); ?></p>
                </div>

                <!-- Title -->
                <div class="col-md-6 mb-3">
                    <strong>Title:</strong>
                    <p><?php echo e($subscription->title ?? '-'); ?></p>
                </div>

                <!-- Monthly Price -->
                <div class="col-md-6 mb-3">
                    <strong>Monthly Price:</strong>
                    <p><?php echo e(number_format($subscription->monthly_price, 2)); ?></p>
                </div>

                <!-- Yearly Price -->
                <div class="col-md-6 mb-3">
                    <strong>Yearly Price:</strong>
                    <p><?php echo e(number_format($subscription->yearly_price, 2)); ?></p>
                </div>

                <!-- Popular -->
                <div class="col-md-6 mb-3">
                    <strong>Popular:</strong>
                    <p><?php echo e($subscription->is_popular ? 'Yes' : 'No'); ?></p>
                </div>

                <!-- Status -->
                <div class="col-md-6 mb-3">
                    <strong>Status:</strong>
                    <p><?php echo e($subscription->is_active ? 'Active' : 'Inactive'); ?></p>
                </div>

                <!-- Features -->
                <div class="col-md-12 mb-3">
                    <strong>Features:</strong>
                    <?php if(count($subscription->features) > 0): ?>
                        <ul>
                            <?php $__currentLoopData = $subscription->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($feature); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p>-</p>
                    <?php endif; ?>
                </div>

            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/subscriptions/view.blade.php ENDPATH**/ ?>