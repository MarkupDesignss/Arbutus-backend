<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Snapshot Details - <?php echo e($snapshot->fund->fundatakey ?? 'Fund'); ?> (<?php echo e($snapshot->as_of_month); ?>)</h1>

    <div class="card mb-3">
        <div class="card-body">
            <p><strong>One Month:</strong> <?php echo e(number_format($snapshot->one_month * 100, 2)); ?>%</p>
            <p><strong>YTD:</strong> <?php echo e(is_null($snapshot->ytd) ? '-' : number_format($snapshot->ytd * 100, 2) . '%'); ?></p>
            <p><strong>One Year:</strong> <?php echo e(is_null($snapshot->one_year) ? '-' : number_format($snapshot->one_year * 100, 2) . '%'); ?></p>
            <p><strong>Three Year (annualised):</strong> <?php echo e(is_null($snapshot->three_year) ? '-' : number_format($snapshot->three_year * 100, 2) . '%'); ?></p>
            <p><strong>Since Inception (annualised):</strong> <?php echo e(is_null($snapshot->since_inception) ? '-' : number_format($snapshot->since_inception * 100, 2) . '%'); ?></p>
            <p><strong>Three Year Std Dev (annualised):</strong> <?php echo e(is_null($snapshot->three_year_std_dev) ? '-' : number_format($snapshot->three_year_std_dev * 100, 2) . '%'); ?></p>
            <p><strong>Distribution Yield:</strong> <?php echo e(is_null($snapshot->distribution_yield) ? '-' : number_format($snapshot->distribution_yield, 2) . '%'); ?></p>
            <p><strong>Published:</strong> <?php echo e($snapshot->is_published ? 'Yes' : 'No'); ?></p>
        </div>
    </div>

    <h3>Monthly Returns (most recent first)</h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Month End</th>
                <th>Monthly Return</th>
                <th>Distribution Yield</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monthlyReturns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($row->month_end)->format('Y-m-d')); ?></td>
                    <td><?php echo e(is_null($row->monthly_return) ? '-' : number_format($row->monthly_return * 100, 2) . '%'); ?></td>
                    <td><?php echo e(is_null($snapshot->distribution_yield) ? '-' : number_format($snapshot->distribution_yield, 2) . '%'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('admin.fund.performance.list')); ?>" class="btn btn-secondary">Back to list</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/fund_performance_snapshots/show.blade.php ENDPATH**/ ?>