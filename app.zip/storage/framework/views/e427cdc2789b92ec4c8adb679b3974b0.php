
<?php $__env->startSection('content'); ?>

<div class="container mt-4">

    
    <div class="d-flex justify-content-between align-items-center mb-3 listing_name">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">
            Fund Performance Snapshots
        </h3>
    </div>

    
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form id="snapshot-form" method="POST" action="<?php echo e(route('admin.fund.performance.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row align-items-end">
                    
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Fund</label>
                        <select id="fund-select" name="fund_id" class="form-select">
                            <option value="">-- Select Fund --</option>
                            <?php $__currentLoopData = $fundOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($opt->fund_id); ?>">
                                <?php echo e(optional($opt->fund)->fund_name ?? 'Unknown'); ?> - <?php echo e($opt->fundatakey); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__errorArgs = ['fund_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </select>
                    </div>

                    
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">As Of Month</label>
                        <select id="month-select" name="as_of_month" class="form-select">
                            <option value="">-- Select Month --</option>
                        </select>
                    </div>

                    
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">
                            Calculate
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card shadow-sm">
        <div class="card-body">
            <h3 class="mb-3 fw-semibold" style="color: #0d6efd;">Snapshots List</h3>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light text-uppercase">
                        <tr>
                            <th>Fund</th>
                            <th>As Of Month</th>
                            <th>1 Month</th>
                            <th>YTD</th>
                            <th>1 Year</th>
                            <th>3 Year</th>
                            <th>Since Inception</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $snapshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(optional($s->fund)->fund_name); ?></td>
                            <td><?php echo e($s->as_of_month); ?></td>
                            <td><?php echo e($s->one_month); ?></td>
                            <td><?php echo e($s->ytd); ?></td>
                            <td><?php echo e($s->one_year); ?></td>
                            <td><?php echo e($s->three_year); ?></td>
                            <td><?php echo e($s->since_inception); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="form-check form-switch me-2">
                                        <input class="form-check-input toggle-switch" type="checkbox" role="switch"
                                               id="publish-<?php echo e($s->id); ?>" data-id="<?php echo e($s->id); ?>" <?php echo e($s->is_published ? 'checked' : ''); ?>>
                                    </div>
                                    <span class="badge publish-badge <?php echo e($s->is_published ? 'bg-success' : 'bg-secondary'); ?>"
                                          data-id="<?php echo e($s->id); ?>"><?php echo e($s->is_published ? 'Active' : 'Inactive'); ?></span>
                                </div>
                            </td>
                            <td>                                
                                <a href="<?php echo e(route('admin.fund.performance.view', $s->id)); ?>"
                                    class="btn btn-sm btn-outline-info ms-1" title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <form action="<?php echo e(route('admin.fund.performance.destroy', $s->id)); ?>" method="POST"
                                    class="d-inline ms-1"
                                    onsubmit="return confirm('Are you sure you want to delete this snapshot?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted">
                                No snapshots found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const fundSelect = document.getElementById('fund-select');
    const monthSelect = document.getElementById('month-select');
    const monthsBaseUrl = "<?php echo e(url('admin/fund-performance-snapshots/months')); ?>";

    fundSelect.addEventListener('change', function() {
        const fundId = this.value;
        monthSelect.innerHTML = '<option value="">-- Select Month --</option>';
        if (!fundId) return;

        fetch(monthsBaseUrl + '/' + fundId, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (!Array.isArray(data)) return;

                data.forEach(row => {
                    const opt = document.createElement('option');
                    opt.value = row.month_end;
                    opt.text = row.month_end;
                    monthSelect.appendChild(opt);
                });

                if (data.length > 0) {
                    monthSelect.selectedIndex = 1;
                }
            })
            .catch(console.error);
    });

    // Toggle publish (form-switch)
    const csrfToken = '<?php echo e(csrf_token()); ?>';
    const toggleUrlBase = "<?php echo e(url('admin/fund-performance-snapshots/toggle')); ?>";

    document.querySelectorAll('.toggle-switch').forEach(cb => {
        cb.addEventListener('change', function (e) {
            const id = this.getAttribute('data-id');
            fetch(`${toggleUrlBase}/${id}`, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': csrfToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({})
            })
            .then(res => res.json())
            .then(data => {
                const badge = document.querySelector('.publish-badge[data-id="'+id+'"]');
                if (!badge) return;
                if (parseInt(data.is_published) === 1) {
                    badge.classList.remove('bg-secondary');
                    badge.classList.add('bg-success');
                    badge.textContent = 'Active';
                    document.getElementById('publish-'+id).checked = true;
                } else {
                    badge.classList.remove('bg-success');
                    badge.classList.add('bg-secondary');
                    badge.textContent = 'Inactive';
                    document.getElementById('publish-'+id).checked = false;
                }
            })
            .catch(err => {
                console.error(err);
                // revert checkbox on error
                this.checked = !this.checked;
            });
        });
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/fund_performance_snapshots/index.blade.php ENDPATH**/ ?>