
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 style="font-size: 1.5rem; color: #0d6efd;" class="mb-0 fw-bold">Page Details</h3>
        <a href="<?php echo e(route('admin.pages.list')); ?>" class="btn btn-outline-primary">
            <i class="bi bi-arrow-left me-1"></i>Back to List
        </a>

    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="mb-3"><strong>Title:</strong> <?php echo e($page->title); ?></div>
            <div class="mb-3"><strong>Slug:</strong> <?php echo e($page->slug); ?></div>
            <div class="mb-3"><strong>Meta Tags:</strong> <?php echo e($page->meta_tags ?? '-'); ?></div>
            <div class="mb-3"><strong>Content:</strong> <?php echo $page->content ?? '-'; ?></div>
            <div class="mb-3">
                <strong>Status:</strong>
                <?php if($page->status==1): ?>
                    <span class="badge bg-success">Active</span>
                <?php else: ?>
                    <span class="badge bg-danger">Inactive</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\arbutus\resources\views/admin/pages/view.blade.php ENDPATH**/ ?>